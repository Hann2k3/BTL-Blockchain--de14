// app.js
import { ethers } from "https://cdn.jsdelivr.net/npm/ethers@6.6.0/+esm";
import { tokenABI } from "./abi.js";

// 🪙 Token Sepolia mẫu chuẩn ERC20
const tokenAddress = "0x81901400442552e55F53D4E0a1233CD0B09554BB";  // Địa chỉ token ERC20
const systemWallet = "0x9B0739A9f54814ca3A5762E6C82F769FB58BF7c7";   // Ví nhận token khi vote

let provider;
let signer;
let userAddress;

const projects = [
  "Dự án AI cho Nông nghiệp",
  "Dự án Đô thị thông minh",
  "Dự án Blockchain Giáo dục",
  "Dự án Camera giao thông",
  "Dự án An ninh mạng IoT"
];

function pickProject() {
  const project = projects[Math.floor(Math.random() * projects.length)];
  document.getElementById("project").innerText = "💡 " + project;
  return project;
}

async function updateBalanceUI() {
  try {
    const tokenContract = new ethers.Contract(tokenAddress, tokenABI, provider);
    const balance = await tokenContract.balanceOf(userAddress);  // balance là bigint
    const formatted = ethers.formatUnits(balance, 18);

    document.getElementById("balance").innerText = `💰 Số dư token: ${formatted}`;
    return balance >= ethers.parseUnits("1", 18);  // ✅ So sánh bigint
  } catch (err) {
    console.error("Lỗi lấy số dư:", err);
    document.getElementById("balance").innerText = "⚠️ Không thể đọc số dư token.";
    return false;
  }
}

async function connectWallet() {
  if (!window.ethereum) {
    alert("⚠️ Bạn cần cài MetaMask để sử dụng!");
    return;
  }

  provider = new ethers.BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  signer = await provider.getSigner();
  userAddress = await signer.getAddress();

  document.getElementById("status").innerText = "✅ Đã kết nối: " + userAddress;
  document.getElementById("connectBtn").disabled = true;

  const hasBalance = await updateBalanceUI();
  document.getElementById("voteBtn").disabled = !hasBalance;

  if (hasBalance) {
    document.getElementById("voteBtn").style.display = "inline-block";
  } else {
    document.getElementById("status").innerText += " | Không đủ token để vote.";
  }

  window.ethereum.on("accountsChanged", () => window.location.reload());
  window.ethereum.on("chainChanged", () => window.location.reload());
}

async function vote() {
  if (!signer || !userAddress) {
    alert("⚠️ Bạn chưa kết nối ví!");
    return;
  }

  const tokenContract = new ethers.Contract(tokenAddress, tokenABI, signer);
  const amount = ethers.parseUnits("1", 18);

  try {
    const balance = await tokenContract.balanceOf(userAddress);
    if (balance < amount) {
      alert("⚠️ Không đủ token!");
      document.getElementById("voteBtn").disabled = true;
      return;
    }

    document.getElementById("status").innerText = "⏳ Đang gửi giao dịch...";
    const tx = await tokenContract.transfer(systemWallet, amount);
    await tx.wait();

    document.getElementById("status").innerText = "🎉 Vote thành công!";
    pickProject();

    const hasBalance = await updateBalanceUI();
    if (!hasBalance) {
      document.getElementById("voteBtn").disabled = true;
      document.getElementById("status").innerText += " | Hết token để vote.";
    }

  } catch (err) {
    console.error(err);
    document.getElementById("status").innerText = "❌ Giao dịch thất bại!";
  }
}

// 👉 Auto connect nếu đã từng kết nối
window.addEventListener("load", async () => {
  pickProject();
  if (window.ethereum) {
    try {
      const accs = await window.ethereum.request({ method: 'eth_accounts' });
      if (accs.length > 0) {
        connectWallet();
      }
    } catch (err) {
      console.warn("Không thể tự động kết nối ví:", err);
    }
  }
});

// Gắn sự kiện
document.getElementById("connectBtn").onclick = connectWallet;
document.getElementById("voteBtn").onclick = vote;
