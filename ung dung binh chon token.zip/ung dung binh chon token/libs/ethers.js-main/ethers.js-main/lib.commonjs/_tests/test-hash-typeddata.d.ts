export {};
//# sourceMappingURL=test-hash-typeddata.d.ts.map