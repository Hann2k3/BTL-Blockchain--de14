export {};
//# sourceMappingURL=test-wallet.d.ts.map