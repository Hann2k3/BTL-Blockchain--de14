export {};
//# sourceMappingURL=test-providers-wildcard.d.ts.map