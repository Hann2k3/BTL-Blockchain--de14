export {};
//# sourceMappingURL=test-wallet-hd.d.ts.map