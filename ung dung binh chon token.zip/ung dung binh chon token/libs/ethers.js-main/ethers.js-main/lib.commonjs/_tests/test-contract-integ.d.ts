export {};
//# sourceMappingURL=test-contract-integ.d.ts.map