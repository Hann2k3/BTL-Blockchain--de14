export declare const ROOT: string;
export declare function resolve(...args: Array<string>): string;
//# sourceMappingURL=path.d.ts.map