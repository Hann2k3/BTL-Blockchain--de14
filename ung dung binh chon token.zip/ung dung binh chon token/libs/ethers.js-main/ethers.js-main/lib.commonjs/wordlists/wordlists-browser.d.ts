import type { Wordlist } from "./wordlist.js";
export declare const wordlists: Record<string, Wordlist>;
//# sourceMappingURL=wordlists-browser.d.ts.map