export declare function loadJson(path: string): any;
export type SortFunc = (parent: string, a: string, b: string) => number;
export declare function saveJson(filename: string, data: any, sort?: boolean | SortFunc): any;
//# sourceMappingURL=json.d.ts.map